import {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";
import { Alert, Settings, Report, Knowledge } from "../types";
import {
  defaultSettings,
  initialAlerts,
  initialKnowledge,
} from "../data/mockData";
function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}
function useStored<T>(key: string, fallback: T) {
  const [value, setValue] = useState<T>(() => read(key, fallback));
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      console.warn("本地存储不可用");
    }
  }, [key, value]);
  return [value, setValue] as const;
}
function useAppState() {
  const [settings, setSettings] = useStored<Settings>(
    "anzhi-settings",
    defaultSettings,
  );
  const [alerts, setAlerts] = useStored<Alert[]>("anzhi-alerts", initialAlerts);
  const [reports, setReports] = useStored<Report[]>("anzhi-reports", []);
  const [knowledge, setKnowledge] = useStored<Knowledge[]>(
    "anzhi-knowledge",
    initialKnowledge,
  );
  const [updates, setUpdates] = useStored<string[]>("anzhi-updates", [
    "典型案例库已初始化 · 10 类诈骗场景",
    "知识索引更新完成 · 文本与多模态案例",
  ]);
  const [loggedIn, setLoggedIn] = useStored("anzhi-session", false);
  const [toast, setToast] = useState("");
  useEffect(() => {
    document.documentElement.style.fontSize = settings.largeFont
      ? "19.2px"
      : "16px";
  }, [settings.largeFont]);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 3500);
    return () => clearTimeout(t);
  }, [toast]);
  const notify = (id: string) => {
    const gs = settings.guardians.filter((g) => g.isDefault);
    if (!gs.length) {
      setToast("请先在角色设置中添加默认通知的监护人");
      return;
    }
    const log = `${new Date().toLocaleString("zh-CN")} · 已模拟通知 ${gs.map((g) => g.name).join("、")} · 短信送达`;
    setAlerts((a) =>
      a.map((x) => (x.id === id ? { ...x, logs: [...x.logs, log] } : x)),
    );
    setToast("已通知监护人（模拟短信）");
  };
  const handle = (ids: string[]) => {
    setAlerts((a) =>
      a.map((x) => (ids.includes(x.id) ? { ...x, handled: true } : x)),
    );
    setToast(`已将 ${ids.length} 条预警标记为已处理`);
  };
  return {
    settings,
    setSettings,
    alerts,
    setAlerts,
    reports,
    setReports,
    knowledge,
    setKnowledge,
    updates,
    setUpdates,
    loggedIn,
    setLoggedIn,
    toast,
    setToast,
    notify,
    handle,
  };
}
const Context = createContext<ReturnType<typeof useAppState> | null>(null);
export function AppProvider({ children }: { children: ReactNode }) {
  return <Context.Provider value={useAppState()}>{children}</Context.Provider>;
}
export function useApp() {
  return useContext(Context)!;
}
