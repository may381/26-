import { useState, useEffect } from "react";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import Assistant from "./pages/Assistant";
import Alerts from "./pages/Alerts";
import Settings from "./pages/Settings";
import Reports from "./pages/Reports";
import Knowledge from "./pages/Knowledge";
import Login from "./pages/Login";
import { Page } from "./types";
import { useApp } from "./context/AppContext";
const pages: Page[] = [
  "dashboard",
  "assistant",
  "alerts",
  "reports",
  "settings",
  "knowledge",
];
function fromHash(): Page {
  const p = location.hash.slice(1) as Page;
  return pages.includes(p) ? p : "dashboard";
}
export default function App() {
  const { loggedIn } = useApp();
  const [page, setPage] = useState<Page>(fromHash);
  const [loginRoute, setLoginRoute] = useState(location.hash === "#login");
  const [mode, setMode] = useState("text");
  const [reportOpen, setReportOpen] = useState(false);
  useEffect(() => {
    const onHash = () => { setPage(fromHash()); setLoginRoute(location.hash === "#login"); };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  function navigate(p: Page) {
    setLoginRoute(false);
    setPage(p);
    location.hash = p;
    if (p !== "reports") setReportOpen(false);
    window.scrollTo(0, 0);
  }
  // Explicit workspace links are accessible in this backend-free demo.
  if (loginRoute || (!loggedIn && !pages.includes(location.hash.slice(1) as Page)))
    return (
      <Login
        onLogin={(register) => navigate(register ? "settings" : "dashboard")}
      />
    );
  return (
    <Layout page={page} navigate={navigate}>
      {page === "dashboard" && (
        <Dashboard
          navigate={navigate}
          detect={(m) => {
            setMode(m);
            navigate("assistant");
          }}
        />
      )}
      {page === "assistant" && (
        <Assistant
          mode={mode}
          onReport={() => {
            setReportOpen(true);
            navigate("reports");
          }}
        />
      )}
      {page === "alerts" && <Alerts />}
      {page === "settings" && <Settings />}
      {page === "reports" && <Reports autoOpen={reportOpen} />}{" "}
      {page === "knowledge" && <Knowledge />}
    </Layout>
  );
}
