export type Risk = "low" | "medium" | "high";
export type Page =
  | "dashboard"
  | "assistant"
  | "alerts"
  | "reports"
  | "settings"
  | "knowledge";
export interface Guardian {
  id: string;
  name: string;
  relation: string;
  phone: string;
  isDefault: boolean;
}
export interface Settings {
  name: string;
  role: string;
  age: string;
  job: string;
  gender: string;
  preference: number;
  largeFont: boolean;
  guardians: Guardian[];
}
export interface Alert {
  id: string;
  level: Risk;
  type: string;
  summary: string;
  time: string;
  user: string;
  handled: boolean;
  confidence: number;
  advice: string[];
  evidence: string;
  logs: string[];
  modality: string;
}
export interface Report {
  id: string;
  start: string;
  end: string;
  type: string;
  created: string;
}
export interface Knowledge {
  id: string;
  type: string;
  keywords: string;
  count: number;
  updated: string;
}
export interface Scenario {
  id: string;
  name: string;
  level: Risk;
  type: string;
  confidence: number;
  text: string;
  reply: string;
  advice: string[];
  modality: string;
}
