import { ReactNode, useEffect, useRef } from "react";
import { X, ShieldCheck, ArrowUpRight } from "lucide-react";
import { Risk, Alert } from "../types";
import { useApp } from "../context/AppContext";
export const riskLabels = { low: "低风险", medium: "中风险", high: "高风险" };
export function Badge({ level }: { level: Risk }) {
  return (
    <span className={`badge ${level}`}>
      <i />
      {riskLabels[level]}
    </span>
  );
}
export function Heading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {action}
    </div>
  );
}
export function Modal({
  title,
  children,
  onClose,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const old = document.activeElement as HTMLElement;
    ref.current?.focus();
    const fn = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeRef.current();
      if (e.key === "Tab") {
        const els = ref.current?.querySelectorAll<HTMLElement>(
          'button,input,select,textarea,[tabindex="0"]',
        );
        if (!els?.length) return;
        const first = els[0],
          last = els[els.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", fn);
    return () => {
      document.removeEventListener("keydown", fn);
      old?.focus();
    };
  }, []);
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        ref={ref}
        onClick={(e) => e.stopPropagation()}
      >
        <header>
          <h2>{title}</h2>
          <button className="icon-button" aria-label="关闭" onClick={onClose}>
            <X size={20} />
          </button>
        </header>
        {children}
      </div>
    </div>
  );
}
export function AlertDetail({
  alert,
  onClose,
}: {
  alert: Alert;
  onClose: () => void;
}) {
  const { notify, handle } = useApp();
  return (
    <Modal title="风险事件详情" onClose={onClose}>
      <div className="flex items-center gap-3">
        <Badge level={alert.level} />
        <strong>{alert.type}</strong>
        <span className="muted">
          {new Date(alert.time).toLocaleString("zh-CN")}
        </span>
      </div>
      <h3>对话与输入内容</h3>
      <div className="quote">{alert.summary}</div>
      <h3>多模态分析 · {alert.modality}</h3>
      <p>{alert.evidence}</p>
      <p className="muted">
        模拟置信度 {alert.confidence}% · 用户：{alert.user}
      </p>
      <h3>防御建议</h3>
      <ul className="advice">
        {alert.advice.map((x) => (
          <li key={x}>
            <ShieldCheck size={17} />
            {x}
          </li>
        ))}
      </ul>
      <h3>监护人通知记录</h3>
      {alert.logs.length ? (
        alert.logs.map((x, i) => (
          <p className="log" key={i}>
            {x}
          </p>
        ))
      ) : (
        <p className="muted">暂无通知记录</p>
      )}
      <div className="modal-actions">
        <button
          className="button secondary"
          disabled={alert.handled}
          onClick={() => handle([alert.id])}
        >
          {alert.handled ? "已处理" : "标记已处理"}
        </button>
        <button className="button" onClick={() => notify(alert.id)}>
          通知监护人
          <ArrowUpRight size={16} />
        </button>
      </div>
    </Modal>
  );
}
export function Empty({ text = "暂无记录" }: { text?: string }) {
  return (
    <div className="empty">
      <ShieldCheck size={34} />
      <p>{text}</p>
    </div>
  );
}
