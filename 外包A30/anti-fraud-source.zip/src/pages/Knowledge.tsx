import { useRef, useState, useEffect } from "react";
import {
  Database,
  Upload,
  RefreshCw,
  CheckCircle2,
  FileText,
} from "lucide-react";
import { useApp } from "../context/AppContext";
import { fraudTypes, today } from "../data/mockData";
import { Heading } from "../components/UI";
import Loader from "../components/Loader";
export default function Knowledge() {
  const { knowledge, setKnowledge, updates, setUpdates, setToast } = useApp();
  const [text, setText] = useState("");
  const [type, setType] = useState(fraudTypes[0]);
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const [fileName, setFileName] = useState("");
  const file = useRef<HTMLInputElement>(null);
  const timer = useRef<ReturnType<typeof setInterval>>();
  useEffect(() => () => clearInterval(timer.current), []);
  async function load(f?: File) {
    if (!f) return;
    if (!/\.(txt|json|csv)$/i.test(f.name) || f.size > 2 * 1024 * 1024) {
      setToast("请上传不超过 2 MB 的 .txt、.json 或 .csv 文件");
      return;
    }
    try {
      const content = await f.text();
      if (f.name.endsWith(".json")) JSON.parse(content);
      setText(content);
      setFileName(f.name);
      setToast("案例文件已读取，请确认内容后入库");
    } catch {
      setToast("文件读取失败或 JSON 格式不正确");
    }
  }
  function ingest() {
    if (!text.trim()) {
      setToast("请先粘贴案例或上传文件");
      return;
    }
    setBusy(true);
    setProgress(0);
    let p = 0;
    timer.current = setInterval(() => {
      p += 20;
      setProgress(p);
      if (p >= 100) {
        clearInterval(timer.current);
        setKnowledge((ks) =>
          ks.map((k) =>
            k.type === type ? { ...k, count: k.count + 1, updated: today } : k,
          ),
        );
        setUpdates((ls) => [
          `${new Date().toLocaleString("zh-CN")} · ${type} · 新增 1 个案例，清洗与索引模拟完成`,
          ...ls,
        ]);
        setBusy(false);
        setText("");
        setFileName("");
        setToast("清洗完成，案例已模拟入库");
      }
    }, 350);
  }
  return (
    <>
      <Heading
        eyebrow="CONTINUOUS LEARNING"
        title="知识库进化"
        description="让每一个新案例，成为下一次识别的经验。"
        action={
          <span className="model-chip">
            <Database size={16} />
            {knowledge.reduce((s, k) => s + k.count, 0).toLocaleString()} 个案例
            · {knowledge.length} 类场景
          </span>
        }
      />
      <div className="knowledge-grid">
        <section className="panel knowledge-table">
          <div className="panel-heading">
            <h2>反诈知识库</h2>
            <span className="muted text-xs">本地模拟索引</span>
          </div>
          <div className="knowledge-row knowledge-head">
            <span>诈骗类型 / 关键词</span>
            <span>案例数</span>
            <span>最后更新</span>
          </div>
          {knowledge.map((k) => (
            <div className="knowledge-row" key={k.id}>
              <div>
                <strong>{k.type}</strong>
                <small>{k.keywords}</small>
              </div>
              <span>{k.count}</span>
              <time>{k.updated}</time>
            </div>
          ))}
        </section>
        <div className="space-y-5">
          <section className="panel form-panel">
            <h2>
              <Upload size={20} />
              上传新案例
            </h2>
            <p className="muted">支持文本及文件导入，演示清洗与入库流程。</p>
            <label className="field-label">
              诈骗类型
              <select
                value={type}
                disabled={busy}
                onChange={(e) => setType(e.target.value)}
              >
                {fraudTypes.map((x) => (
                  <option key={x}>{x}</option>
                ))}
              </select>
            </label>
            <textarea
              aria-label="案例内容"
              className="case-text"
              disabled={busy}
              placeholder="粘贴案例内容，包含诈骗话术、过程与风险特征…"
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
            <button
              disabled={busy}
              className="upload-zone"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                if (!busy) load(e.dataTransfer.files[0]);
              }}
              onClick={() => file.current?.click()}
            >
              <FileText size={24} />
              <strong>{fileName || "点击或拖拽文件到这里"}</strong>
              <small>.txt / .json / .csv · 最大 2 MB</small>
            </button>
            <input
              hidden
              type="file"
              ref={file}
              accept=".txt,.json,.csv"
              onChange={(e) => {
                load(e.target.files?.[0]);
                e.target.value = "";
              }}
            />
            {busy && <Loader label="正在清洗案例并创建模拟索引…" />}
            {progress > 0 && (
              <div className="ingest-progress">
                <span>
                  {progress === 100
                    ? "清洗与入库完成"
                    : "正在清洗、去重并创建模拟索引…"}{" "}
                  {progress}%
                </span>
                <div className="progress-track">
                  <span style={{ width: `${progress}%` }} />
                </div>
              </div>
            )}
            <button
              className="button w-full justify-center mt-4"
              disabled={busy || !text.trim()}
              onClick={ingest}
            >
              {!busy && <RefreshCw size={16} />}
              {busy ? "正在处理…" : "清洗并入库"}
            </button>
          </section>
          <section className="panel update-panel">
            <h2>更新日志</h2>
            <div className="timeline">
              {updates.slice(0, 6).map((u, i) => (
                <div key={`${u}${i}`}>
                  <CheckCircle2 size={16} />
                  <p>{u}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </>
  );
}
