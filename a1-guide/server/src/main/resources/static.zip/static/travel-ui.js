'use strict';
let travelDraft=null,travelWizard=null,travelEpoch=0;
const draftDialog=document.querySelector('#draft-dialog');
const planDateLocal=()=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai'}).format(new Date());
function node(tag,text,cls){const element=document.createElement(tag);if(text)element.textContent=text;if(cls)element.className=cls;return element;}
function choiceButton(text,action){const b=node('button',text);b.type='button';b.onclick=action;return b;}
function wizardStart(destination=''){
 if(busy)return;travelEpoch++;travelWizard={destination,startDate:planDateLocal(),days:2,walkMinutes:40,companions:'独自出游',step:0};
 message(destination?'帮我准备去'+destination+'的出游计划':'帮我准备出游计划',{mine:true});
 showWizard();input.value='';resizeInput();closeMore();closeSidebar();
}
window.beginPlanFromText=text=>{if(!/计划|行程安排|几日游|几天游/.test(text)||/取消|不想|不要/.test(text))return false;let destination=text.match(/(?:想去|计划去|去)([\p{Script=Han}]{2,15}?)(?:旅游|游玩|旅行|[，,。！!]|$)/u)?.[1]||'';wizardStart(destination);return true;};
function showWizard(){
 const state=travelWizard;if(!state)return;
 const row=message(['您想去哪个城市？','打算什么时候出发？','这次想怎样慢慢游？'][state.step],{meta:'出游准备 · 第 '+(state.step+1)+' 步，共 3 步'});
 const card=node('section',null,'wizard-card');row.querySelector('.message-content').append(card);
 const cancel=choiceButton('取消准备',()=>{card.replaceChildren(node('p','已取消，可以继续聊天。'));travelWizard=null;});cancel.className='wizard-cancel';
 if(state.step===0){const label=node('label','目的地城市');const destination=node('input');destination.value=state.destination;destination.placeholder='例如：北京、阳江';destination.maxLength=40;destination.setAttribute('aria-label','目的地城市');card.append(label,destination);const next=choiceButton('下一步',()=>{if(!destination.value.trim()){destination.focus();return;}state.destination=destination.value.trim();state.step=1;card.replaceChildren(node('p','目的地：'+state.destination));message(state.destination,{mine:true});showWizard();});next.className='wizard-primary';card.append(next);}
 if(state.step===1){const label=node('label','出发日期');const date=node('input');date.type='date';date.min=planDateLocal();date.value=state.startDate;date.setAttribute('aria-label','出发日期');const next=choiceButton('确认日期',()=>{if(!date.reportValidity()||!date.value||date.value<planDateLocal())return;state.startDate=date.value;state.step=2;card.replaceChildren(node('p','出发日期：'+state.startDate));message(state.startDate,{mine:true});showWizard();});next.className='wizard-primary';card.append(label,date);renderPlanCalendar(card,date);card.append(next);}
 if(state.step===2){
  const groups=[['游玩天数','days',[[1,'1 天'],[2,'2 天'],[3,'3 天'],[4,'4 天']]],['一次想走多久','walkMinutes',[[20,'约20分钟'],[40,'约40分钟'],[60,'约1小时']]],['同行情况','companions',[['独自出游','独自出游'],['家人同行','家人同行'],['朋友同行','朋友同行']]]];
  for(const [title,key,options]of groups){const section=node('fieldset');section.append(node('legend',title));const group=node('div',null,'wizard-options');for(const [value,label]of options){const b=choiceButton(label,()=>{state[key]=value;group.querySelectorAll('button').forEach(x=>x.setAttribute('aria-pressed','false'));b.setAttribute('aria-pressed','true');});b.setAttribute('aria-pressed',String(state[key]===value));group.append(b);}section.append(group);card.append(section);}
  const finish=choiceButton('查询真实地点，生成草案',()=>createTravelDraft(state,card));finish.className='wizard-primary';card.append(node('p','这是出游建议草案，不会自动开始游览或订票。','wizard-note'),finish);
 }
 card.append(cancel);toLatest();
}
async function createTravelDraft(state,card){
 if(busy||travelWizard!==state)return;const epoch=travelEpoch;setBusy(true);card.querySelectorAll('button').forEach(b=>b.disabled=true);
 const row=message('正在准备您的出游草案…',{meta:'实际查询进度'});const trace=document.createElement('details');trace.className='execution-trace';trace.open=true;const traceSummary=node('summary','正在查询地点…'),traceList=node('div');trace.append(traceSummary,traceList);row.querySelector('.message-content').append(trace);let success=false;
 try{const {step,...request}=state;const controller=new AbortController();const stop=choiceButton('停止查询',()=>controller.abort());trace.append(stop);
 const response=await fetch('/api/a1/travel-drafts/stream',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(request),signal:controller.signal});
 if(!response.ok){const error=await response.json();throw new Error(error.message||'请求失败');}
 const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='',result=null;
 while(true){const {done,value}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});let split;
 while((split=buffer.indexOf('\n\n'))!==-1){const event=buffer.slice(0,split).replace(/\r/g,'');buffer=buffer.slice(split+2);const type=event.match(/^event:(.*)$/m)?.[1]?.trim();const payload=event.split('\n').filter(line=>line.startsWith('data:')).map(line=>line.slice(5)).join('\n');if(!payload)continue;const data=JSON.parse(payload);
 if(type==='progress'){traceSummary.textContent=data.message;traceList.append(node('p',data.message));toLatest();}else if(type==='result')result=data;else if(type==='failure')throw new Error(data.message);}}
 if(!result||result.code!=='OK')throw new Error('查询未完成，请重试。');stop.remove();traceSummary.textContent='地点查询与草案整理完成';trace.open=false;
 if(epoch!==travelEpoch)return;
 travelDraft=result.data;travelWizard=null;success=true;row.querySelector('.bubble').textContent='已完成地点查询，下面是出游建议。';card.replaceChildren(node('p','已确认：'+state.destination+'，'+state.startDate+'出发，'+state.days+'天，'+state.companions+'。'));
 const answer=message('根据高德查到的地点，我先整理了一份可调整的慢游草案。每天'+(state.walkMinutes<=20?'先看一个地点':'先看两个地点')+'，您可以再删减。地点次序尚未按真实交通路线优化，台阶、休息点和开放状态需要进一步核实。',{meta:'高德地点资料 · 建议草案'});
 renderDraftCard(answer.querySelector('.message-content'),travelDraft);document.querySelector('.topbar-title').firstChild.textContent=state.destination+'出游计划';
 }catch(error){traceSummary.textContent=error.name==='AbortError'?'查询已停止':'查询未完成';trace.querySelector('button')?.remove();message(error.name==='AbortError'?'已停止接收本次结果，未执行草案保存操作。':error.name==='TimeoutError'?'地点查询超时，请重试。':error.message,{error:true});}finally{setBusy(false);if(!success)card.querySelectorAll('button').forEach(b=>b.disabled=false);}
}
function renderDraftCard(target,draft){
 const card=node('section',null,'draft-summary narrative-draft');card.append(node('div','建议草案 · 尚未开始游览','draft-eyebrow'),node('h2',draft.title),node('p',draft.preferences.startDate+' 起 · '+draft.days.length+'天','draft-dates'));
 for(const [i,day]of draft.days.entries()){
  const block=node('section',null,'narrative-day');block.append(node('h3','第'+(i+1)+'天 · '+day.date));
  const text=node('p');if(day.places.length){text.append(document.createTextNode('这一天先考虑 '));day.places.forEach((place,j)=>{if(j)text.append(document.createTextNode('，之后再考虑 '));const link=choiceButton(place.name,()=>openPlaceMap(place));link.className='place-text-link';text.append(link);});text.append(document.createTextNode('。您可以根据当天状态删减地点，停留时间和交通安排需要进一步确认。'));}else text.textContent='当天暂无足够地点资料，可以留作休息或继续补充。';block.append(text);
  const gallery=node('div',null,'narrative-gallery');const images=[],seen=new Set();let offset=0;
  while(images.length<3){let added=false;for(const place of day.places){const url=place.photos?.[offset];if(url&&!seen.has(url)){seen.add(url);images.push({url,place});added=true;if(images.length===3)break;}}if(!added)break;offset++;}
  for(const {url,place}of images){const button=choiceButton('',()=>openPhoto(url,place));button.setAttribute('aria-label','查看'+place.name+'照片');const image=node('img');image.src=url;image.alt=place.name+' · 高德地点照片';image.loading='lazy';image.referrerPolicy='no-referrer';image.onerror=()=>button.remove();button.append(image);gallery.append(button);}
  if(images.length){block.append(gallery,node('p','图片来源：高德地点照片；仅代表对应地点。','gallery-source'));}card.append(block);
 }
 card.append(choiceButton('查看与调整草案 ↗',()=>openDraft(draft)),node('p','以上按已查询地点整理，未核验路网次序、天气、台阶和营业状态。','wizard-note'));target.append(card);toLatest();
}
function openPhoto(url,place){const dialog=document.querySelector('#photo-dialog');document.querySelector('#photo-full').src=url;document.querySelector('#photo-label').textContent=place.name+' · 高德地点照片';dialog.showModal();}
function openDraft(draft){travelDraft=draft;draftDialog.showModal();renderDraftDetail(0);window.setTripSheet?.(.55);}
function renderDraftDetail(active){if(active===-1){renderTripOverview();return;}const root=document.querySelector('#draft-detail');root.replaceChildren(node('h1',travelDraft.title),node('p',travelDraft.preferences.startDate+' 起 · '+travelDraft.days.length+' 天 · 建议草案','draft-dates'));const tabs=node('nav',null,'draft-tabs');tabs.setAttribute('aria-label','按天查看');travelDraft.days.forEach((day,i)=>{const b=choiceButton('第'+(i+1)+'天',()=>renderDraftDetail(i));b.setAttribute('aria-pressed',String(i===active));tabs.append(b);});const overview=choiceButton('总览',()=>renderDraftDetail(-1));overview.setAttribute('aria-pressed','false');tabs.prepend(overview);root.append(tabs);
 window.showTripDay?.(travelDraft,active);const day=travelDraft.days[active];root.append(node('h2',day.date));if(!day.places.length)root.append(node('p','当天暂无地点资料，可留作休息。'));
 day.places.forEach((place,index)=>{const item=node('article',null,'draft-stop');item.dataset.placeId=place.id;item.append(node('span',String(index+1),'stop-number'),node('h3',place.name),node('p',place.address));const controls=node('div',null,'stop-actions');controls.append(choiceButton('地图定位',()=>window.focusTripPlace?.(place.id)),choiceButton('问问这个地点',()=>{draftDialog.close();selectedPlace=place;document.querySelector('#scene-name').textContent=place.name;sendMessage('介绍一下'+place.name+'，请根据查到的资料回答。');}),choiceButton('移除此地点',()=>{day.places.splice(index,1);renderDraftDetail(active);showToast('已移除，点击保存后生效');}));if(index>0)controls.append(choiceButton('上移',()=>{[day.places[index-1],day.places[index]]=[day.places[index],day.places[index-1]];renderDraftDetail(active);}));if(index<day.places.length-1)controls.append(choiceButton('下移',()=>{[day.places[index+1],day.places[index]]=[day.places[index],day.places[index+1]];renderDraftDetail(active);}));if(index<day.places.length-1)controls.append(choiceButton('到下一站的交通',()=>openTransportInfo(place,day.places[index+1])));item.querySelector('h3').onclick=()=>window.focusTripPlace?.(place.id);item.append(controls);root.append(item);});appendDraftEditing(root,active);root.append(node('p','修改后请点保存。保存的是出游草案，不会开始正式旅程；实际路程、体力适配和开放状态仍需核实。','wizard-note'));}
document.querySelector('#draft-close').onclick=()=>draftDialog.close();document.querySelector('#draft-copy').onclick=async()=>{if(!travelDraft)return;const text=travelDraft.title+'\n'+travelDraft.days.map((d,i)=>'第'+(i+1)+'天 '+d.date+'：'+d.places.map(p=>p.name).join(' → ')).join('\n')+'\n建议草案，路线与开放情况待核实。';try{await navigator.clipboard.writeText(text);showToast('已复制草案');}catch{showToast('当前浏览器无法复制');}};
document.querySelector('#start-plan').onclick=()=>wizardStart();document.querySelector('#plan-tool').onclick=()=>wizardStart();document.querySelector('#start-place').onclick=()=>{input.value='我想了解';input.focus();resizeInput();};document.querySelector('#place-tool').onclick=()=>placesDialog.showModal();
window.clearTravelDraft=()=>{travelEpoch++;travelDraft=null;travelWizard=null;document.querySelector('.topbar-title').firstChild.textContent='问问小颐';};

function renderPlanCalendar(target,inputDate){
 let [year,month]=inputDate.value.split('-').map(Number);month--;const calendar=node('section',null,'plan-calendar');target.append(calendar);
 const draw=()=>{calendar.replaceChildren();const header=node('div',null,'calendar-header');const previous=choiceButton('‹',()=>{month--;if(month<0){month=11;year--;}draw();}),next=choiceButton('›',()=>{month++;if(month>11){month=0;year++;}draw();});previous.setAttribute('aria-label','上个月');next.setAttribute('aria-label','下个月');header.append(previous,node('strong',year+'年'+(month+1)+'月'),next);calendar.append(header);const grid=node('div',null,'calendar-grid');for(const label of ['日','一','二','三','四','五','六'])grid.append(node('span',label));
 const first=new Date(year,month,1).getDay(),days=new Date(year,month+1,0).getDate();for(let i=0;i<first;i++)grid.append(node('span'));
 for(let day=1;day<=days;day++){const value=year+'-'+String(month+1).padStart(2,'0')+'-'+String(day).padStart(2,'0');const b=choiceButton(String(day),()=>{inputDate.value=value;draw();});b.disabled=value<planDateLocal();b.setAttribute('aria-label',value);b.setAttribute('aria-pressed',String(inputDate.value===value));grid.append(b);}calendar.append(grid);};inputDate.addEventListener('change',()=>{[year,month]=inputDate.value.split('-').map(Number);month--;draw();});draw();
}

let savingDraft=false;
function appendDraftEditing(root,active){
 const section=node('section',null,'draft-editing');const heading=node('h3','添加真实地点');const query=node('input');query.placeholder='搜索景点、住宿或机场';query.maxLength=100;query.setAttribute('aria-label','要添加的地点');const results=node('div');const search=choiceButton('搜索地点',async()=>{if(!query.value.trim())return;search.disabled=true;results.replaceChildren(node('p','正在查询…'));try{const response=await fetch('/api/a1/places?'+new URLSearchParams({query:query.value.trim(),city:travelDraft.preferences.destination}),{signal:AbortSignal.timeout(20000)});const data=await response.json();if(!response.ok||data.code!=='OK')throw new Error(data.message||'查询失败');results.replaceChildren();for(const place of data.data.places){const b=choiceButton(place.name+' · 添加',()=>{if(travelDraft.days.some(d=>d.places.some(p=>p.id===place.id))){showToast('此地点已在草案中');return;}if(travelDraft.days[active].places.length>=8){showToast('每天最多8个地点，建议适量安排');return;}travelDraft.days[active].places.push(place);renderDraftDetail(active);showToast('已添加，记得保存');});results.append(b);}if(!data.data.places.length)results.append(node('p','没有查到，请换个名称。'));}catch(e){results.replaceChildren(node('p',e.message));}finally{search.disabled=false;}});section.append(heading,query,search,results);
 const save=choiceButton('保存草案',async()=>{if(savingDraft)return;savingDraft=true;save.disabled=true;save.textContent='正在保存…';try{const payload={id:travelDraft.id,title:travelDraft.title,days:travelDraft.days.map(d=>({date:d.date,placeIds:d.places.map(p=>p.id)}))};const response=await fetch('/api/a1/travel-drafts/current',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(60000)});const data=await response.json();if(!response.ok||data.code!=='OK')throw new Error(data.message||'保存失败');travelDraft=data.data;showToast('草案已保存，可在菜单中恢复');save.textContent='已保存';}catch(e){showToast(e.message);save.textContent='重试保存';}finally{savingDraft=false;save.disabled=false;}});save.className='wizard-primary';section.append(save);root.append(section);
}
document.querySelector('#restore-draft').onclick=async()=>{if(busy)return;closeMore();try{const response=await fetch('/api/a1/travel-drafts/current');const data=await response.json();if(!response.ok||data.code!=='OK')throw new Error(data.message||'暂无草案');openDraft(data.data);}catch(e){showToast(e.message);}};

async function openTransportInfo(origin,destination){
 document.querySelector('#place-info-title').textContent='交通信息';placeInfoBody.replaceChildren(node('p',origin.name+' → '+destination.name));placeInfoDialog.showModal();
 const container=node('div',null,'transport-options');placeInfoBody.append(container);const names={walking:'步行',driving:'驾车',transit:'公共交通'};
 for(const mode of ['walking','driving','transit']){const section=node('section',null,'transport-option');section.append(node('strong',names[mode]),node('p','正在查询…'));container.append(section);
 (async()=>{try{const response=await fetch('/api/a1/transport?'+new URLSearchParams({from:origin.id,to:destination.id,mode}),{signal:AbortSignal.timeout(25000)});const data=await response.json();if(!response.ok||data.code!=='OK')throw new Error(data.message||'查询失败');section.replaceChildren(node('strong',names[mode]));const option=data.data.options?.[0];if(!option){section.append(node('p','本次未返回可用方案'));return;}const distance=Number(option.distance),duration=Number(option.duration);section.append(node('p',(Number.isFinite(distance)?(distance/1000).toFixed(1)+'公里':'距离未提供')+' · '+(Number.isFinite(duration)?Math.max(1,Math.round(duration/60))+'分钟':'耗时未提供')));
 if(mode==='transit'){const lines=[];for(const seg of option.segments||[])for(const line of seg.bus?.buslines||[])if(line.name)lines.push(line.name);if(lines.length)section.append(node('p',lines.join(' → ')));if(option.cost!==undefined&&option.cost!=='')section.append(node('p','接口估算费用 '+option.cost+' 元'));}
 }catch(e){section.replaceChildren(node('strong',names[mode]),node('p',e.message||'查询失败'));}})();}
 placeInfoBody.append(node('p','普通交通估算，未核实无障碍、台阶与老人步速；不代表已开始导航，公交时刻与费用以运营方为准。','wizard-note'));
}

document.querySelector('#photo-close').onclick=()=>document.querySelector('#photo-dialog').close();

function renderTripOverview(){const root=document.querySelector('#draft-detail');root.replaceChildren(node('h1',travelDraft.title),node('p','总览 · 建议草案','draft-dates'));const tabs=node('nav',null,'draft-tabs');travelDraft.days.forEach((day,i)=>tabs.append(choiceButton('第'+(i+1)+'天',()=>renderDraftDetail(i))));root.append(tabs);travelDraft.days.forEach((day,index)=>{const block=node('section',null,'draft-day');block.append(node('h3',day.date),node('p',day.places.map(p=>p.name).join(' → ')||'留作休息或待补充'),choiceButton('查看当天',()=>renderDraftDetail(index)));root.append(block);});window.showTripDay?.(travelDraft,-1);}
